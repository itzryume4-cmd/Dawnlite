# DawnLite 1.1 (Fabric 1.21)
Menu modern (RShift / tombol "DawnLite" di pause menu & title screen), HUD bisa digeser,
13 modul HUD, Fullbright, Auto sprint, Toggle sprint/sneak, Zoom halus, dan Optimizer.

## Build dari HP
1. Upload zip ini ke repo GitHub (workflow build.yml unzip + gradle build).
2. Actions -> Run workflow -> download artifact "dawnlite" -> dawnlite-1.1.0.jar.
3. Taruh di mods Zalith (1.21 Fabric) + Fabric API.
