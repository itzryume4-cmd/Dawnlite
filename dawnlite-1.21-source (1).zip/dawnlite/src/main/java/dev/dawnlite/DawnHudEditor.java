package dev.dawnlite;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class DawnHudEditor extends Screen {
    private final Screen parent;
    private HudWidget drag;
    private int offX, offY;

    public DawnHudEditor(Screen parent) {
        super(Text.literal("Atur posisi HUD"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset posisi"), b -> {
            DawnConfig.get().pos.clear();
            DawnConfig.save();
        }).dimensions(width / 2 - 105, height - 28, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Selesai"), b -> close())
                .dimensions(width / 2 + 5, height - 28, 100, 20).build());
    }

    private int[] size(HudWidget w) {
        int ww = w.width(client, textRenderer);
        int hh = w.height(client, textRenderer);
        if (ww <= 0) return new int[]{Math.max(60, textRenderer.getWidth(w.name) + 12), 15, 1};
        return new int[]{ww, hh, 0};
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        DawnConfig c = DawnConfig.get();
        int accent = DawnConfig.accentColor();
        for (HudWidget w : Widgets.ALL) {
            if (!w.enabled(c)) continue;
            int[] sz = size(w);
            int[] p = w.position(c, width, height, sz[0], sz[1]);
            if (sz[2] == 1) {
                Gfx.round(ctx, p[0], p[1], sz[0], sz[1], 3, 0x66000000);
                ctx.drawText(textRenderer, w.name, p[0] + 6, p[1] + 4, 0xFFB8BED6, false);
            } else {
                w.draw(ctx, client, textRenderer, p[0], p[1]);
            }
            ctx.drawBorder(p[0] - 1, p[1] - 1, sz[0] + 2, sz[1] + 2, w == drag ? accent : 0x88FFFFFF);
        }
        ctx.drawCenteredTextWithShadow(textRenderer, "Tahan & geser modul buat mindahin", width / 2, 10, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        DawnConfig c = DawnConfig.get();
        for (int i = Widgets.ALL.size() - 1; i >= 0; i--) {
            HudWidget w = Widgets.ALL.get(i);
            if (!w.enabled(c)) continue;
            int[] sz = size(w);
            int[] p = w.position(c, width, height, sz[0], sz[1]);
            if (mx >= p[0] && mx < p[0] + sz[0] && my >= p[1] && my < p[1] + sz[1]) {
                drag = w;
                offX = (int) mx - p[0];
                offY = (int) my - p[1];
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (drag != null) {
            int[] sz = size(drag);
            int nx = Math.max(0, Math.min((int) mx - offX, width - sz[0]));
            int ny = Math.max(0, Math.min((int) my - offY, height - sz[1]));
            DawnConfig.get().pos.put(drag.id, new int[]{nx, ny});
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (drag != null) {
            drag = null;
            DawnConfig.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
