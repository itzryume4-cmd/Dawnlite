package dev.dawnlite;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayDeque;

public final class DawnHud {
    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
    private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
    private static boolean lastLeft, lastRight;
    private static double speed;

    private DawnHud() {}

    public static int leftCps() { return LEFT.size(); }
    public static int rightCps() { return RIGHT.size(); }
    public static double speed() { return speed; }

    private static void prune(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
    }

    private static void track(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        boolean l = mc.options.attackKey.isPressed();
        boolean r = mc.options.useKey.isPressed();
        if (l && !lastLeft) LEFT.addLast(now);
        if (r && !lastRight) RIGHT.addLast(now);
        lastLeft = l;
        lastRight = r;
        prune(LEFT, now);
        prune(RIGHT, now);
    }

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        track(mc);
        if (mc.player == null) return;
        speed = Math.hypot(mc.player.getX() - mc.player.prevX, mc.player.getZ() - mc.player.prevZ) * 20.0;

        if (mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;
        if (mc.currentScreen instanceof DawnHudEditor || mc.currentScreen instanceof DawnMenuScreen) return;

        DawnConfig c = DawnConfig.get();
        TextRenderer tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        for (HudWidget w : Widgets.ALL) {
            if (!w.enabled(c)) continue;
            int ww = w.width(mc, tr);
            if (ww <= 0) continue;
            int hh = w.height(mc, tr);
            int[] p = w.position(c, sw, sh, ww, hh);
            w.draw(ctx, mc, tr, p[0], p[1]);
        }
    }
}
