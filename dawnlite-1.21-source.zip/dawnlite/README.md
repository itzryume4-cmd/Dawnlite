# DawnLite (Fabric 1.21)
HUD ringan: FPS, CPS, Ping, Koordinat, Keystrokes, Armor HUD, Potion Effects, Auto Sprint, Zoom (tahan C).
Menu: tombol "DawnLite" di pause menu / title screen, atau keybind Right Shift.

## Build tanpa PC (dari HP)
1. Buat repo GitHub, upload semua isi folder ini (termasuk .github).
2. Tab Actions -> workflow "build" -> Run workflow.
3. Download artifact "dawnlite" -> ambil dawnlite-1.0.0.jar.
4. Taruh di folder mods instance Zalith (1.21 Fabric) + Fabric API 0.102.0+1.21 atau lebih baru.
