package dev.dawnlite;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class DawnConfig {
    public boolean fps = true;
    public boolean cps = true;
    public boolean ping = true;
    public boolean coords = true;
    public boolean keystrokes = true;
    public boolean armor = true;
    public boolean potions = true;
    public boolean autoSprint = false;

    private static DawnConfig instance = new DawnConfig();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("dawnlite.json");
    }

    public static DawnConfig get() { return instance; }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                DawnConfig c = GSON.fromJson(Files.readString(p), DawnConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception ignored) {}
        save();
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (Exception ignored) {}
    }
}
