package dev.dawnlite;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class DawnConfigScreen extends Screen {
    private final Screen parent;
    private int col = 0;
    private int row = 0;

    public DawnConfigScreen(Screen parent) {
        super(Text.literal("DawnLite"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        DawnConfig c = DawnConfig.get();
        col = 0;
        row = 0;
        toggle("FPS", () -> c.fps, v -> c.fps = v);
        toggle("CPS", () -> c.cps, v -> c.cps = v);
        toggle("Ping", () -> c.ping, v -> c.ping = v);
        toggle("Koordinat", () -> c.coords, v -> c.coords = v);
        toggle("Keystrokes", () -> c.keystrokes, v -> c.keystrokes = v);
        toggle("Armor HUD", () -> c.armor, v -> c.armor = v);
        toggle("Potion Effects", () -> c.potions, v -> c.potions = v);
        toggle("Auto Sprint", () -> c.autoSprint, v -> c.autoSprint = v);

        addDrawableChild(ButtonWidget.builder(Text.literal("Selesai"), b -> close())
                .dimensions(width / 2 - 100, height - 28, 200, 20).build());
    }

    private void toggle(String name, BooleanSupplier get, Consumer<Boolean> set) {
        int x = col == 0 ? width / 2 - 155 : width / 2 + 5;
        int y = 32 + row * 24;
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(name, get.getAsBoolean()));
            DawnConfig.save();
        }).dimensions(x, y, 150, 20).build());
        if (++col > 1) { col = 0; row++; }
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFF);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
