package dev.dawnlite;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class DawnLiteClient implements ClientModInitializer {
    public static final double ZOOM_FACTOR = 0.25;
    public static KeyBinding zoomKey;
    public static KeyBinding menuKey;

    public static boolean isZooming() {
        return zoomKey != null && zoomKey.isPressed();
    }

    @Override
    public void onInitializeClient() {
        DawnConfig.load();

        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dawnlite.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.dawnlite"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dawnlite.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.dawnlite"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new DawnConfigScreen(client.currentScreen));
            }
            if (DawnConfig.get().autoSprint && client.player != null
                    && client.currentScreen == null
                    && client.options.forwardKey.isPressed()
                    && !client.player.isSneaking()
                    && !client.player.horizontalCollision
                    && client.player.getHungerManager().getFoodLevel() > 6) {
                client.player.setSprinting(true);
            }
        });

        HudRenderCallback.EVENT.register(DawnHud::render);

        // Tombol "DawnLite" di pause menu & title screen, biar bisa dibuka lewat sentuhan
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen || screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("DawnLite"),
                                        b -> MinecraftClient.getInstance().setScreen(new DawnConfigScreen(screen)))
                                .dimensions(4, 4, 70, 20).build());
            }
        });
    }
}
