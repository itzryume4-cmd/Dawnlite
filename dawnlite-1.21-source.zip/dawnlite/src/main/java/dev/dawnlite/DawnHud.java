package dev.dawnlite;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class DawnHud {
    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
    private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
    private static boolean lastLeft, lastRight;

    private DawnHud() {}

    private static void prune(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
    }

    private static void track(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        boolean l = mc.options.attackKey.isPressed();
        boolean r = mc.options.useKey.isPressed();
        if (l && !lastLeft) LEFT.addLast(now);
        if (r && !lastRight) RIGHT.addLast(now);
        lastLeft = l;
        lastRight = r;
        prune(LEFT, now);
        prune(RIGHT, now);
    }

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        track(mc);
        if (mc.player == null || mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;

        DawnConfig c = DawnConfig.get();
        TextRenderer tr = mc.textRenderer;
        int x = 4;
        int y = 4;

        List<String> lines = new ArrayList<>();
        if (c.fps) lines.add("FPS: " + mc.getCurrentFps());
        if (c.cps) lines.add("CPS: " + LEFT.size() + " | " + RIGHT.size());
        if (c.ping && mc.getNetworkHandler() != null && !mc.isInSingleplayer()) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) lines.add("Ping: " + e.getLatency() + " ms");
        }
        if (c.coords) {
            lines.add("XYZ: " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ());
            lines.add("Arah: " + mc.player.getHorizontalFacing().getName());
        }
        for (String s : lines) {
            ctx.drawTextWithShadow(tr, s, x, y, 0xFFFFFF);
            y += 10;
        }

        if (c.keystrokes) {
            y += 4;
            drawKey(ctx, tr, "W", x + 20, y, 18, 18, mc.options.forwardKey.isPressed());
            drawKey(ctx, tr, "A", x, y + 20, 18, 18, mc.options.leftKey.isPressed());
            drawKey(ctx, tr, "S", x + 20, y + 20, 18, 18, mc.options.backKey.isPressed());
            drawKey(ctx, tr, "D", x + 40, y + 20, 18, 18, mc.options.rightKey.isPressed());
            drawKey(ctx, tr, "L", x, y + 40, 29, 16, mc.options.attackKey.isPressed());
            drawKey(ctx, tr, "R", x + 31, y + 40, 29, 16, mc.options.useKey.isPressed());
        }

        if (c.potions) {
            int py = 4;
            int right = ctx.getScaledWindowWidth() - 4;
            boolean flash = (System.currentTimeMillis() / 250) % 2 == 0;
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                String name = e.getEffectType().value().getName().getString() + " " + roman(e.getAmplifier() + 1);
                String time;
                boolean low = false;
                if (e.isInfinite()) {
                    time = "**:**";
                } else {
                    int sec = e.getDuration() / 20;
                    time = (sec / 60) + ":" + String.format("%02d", sec % 60);
                    low = e.getDuration() < 200;
                }
                String line = name + " " + time;
                int color = (low && flash) ? 0xFF5555 : 0xFFFFFF;
                ctx.drawTextWithShadow(tr, line, right - tr.getWidth(line), py, color);
                py += 10;
            }
        }

        if (c.armor) {
            int ax = ctx.getScaledWindowWidth() - 22;
            int ay = ctx.getScaledWindowHeight() / 2 - 40;
            for (int i = 3; i >= 0; i--) {
                ItemStack st = mc.player.getInventory().armor.get(i);
                if (!st.isEmpty()) {
                    ctx.drawItem(st, ax, ay);
                    ctx.drawItemInSlot(tr, st, ax, ay);
                }
                ay += 18;
            }
        }
    }

    private static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return (n >= 1 && n < r.length) ? r[n] : String.valueOf(n);
    }

    private static void drawKey(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w, int h, boolean down) {
        ctx.fill(x, y, x + w, y + h, down ? 0xAAFFFFFF : 0x66000000);
        int color = down ? 0x000000 : 0xFFFFFF;
        ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2, color, false);
    }
}
