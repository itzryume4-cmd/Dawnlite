# DawnLite 1.3 (Fabric 1.21.11)
Port dari DawnLite 1.21. Tambahan: Lunge Swap (tahan V), menu baru, API 1.21.11.
Build: upload zip ke repo, workflow build-1-21-11 akan menghasilkan dawnlite-1.21.11-1.3.0.jar.
