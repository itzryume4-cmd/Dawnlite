package dev.dawnlite.mixin;

import dev.dawnlite.DawnLiteClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(net.minecraft.client.render.GameRenderer.class)
public class GameRendererMixin {
    @SuppressWarnings({"rawtypes", "unchecked"})
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void dawnlite$zoom(CallbackInfoReturnable cir) {
        double m = DawnLiteClient.zoomMultiplier();
        if (m >= 0.999) return;
        Object v = cir.getReturnValue();
        if (v instanceof Float f) {
            cir.setReturnValue((float) (f * m));
        } else if (v instanceof Double d) {
            cir.setReturnValue(d * m);
        }
    }
}
