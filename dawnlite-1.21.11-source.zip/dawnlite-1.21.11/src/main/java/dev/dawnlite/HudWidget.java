package dev.dawnlite;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public abstract class HudWidget {
    public final String id;
    public final String name;
    // anchor default: ax 0=kiri 1=kanan, ay 0=atas 1=bawah 2=tengah
    private final int ax, ay, ox, oy;

    protected HudWidget(String id, String name, int ax, int ay, int ox, int oy) {
        this.id = id;
        this.name = name;
        this.ax = ax;
        this.ay = ay;
        this.ox = ox;
        this.oy = oy;
    }

    public abstract boolean enabled(DawnConfig c);
    public abstract int width(MinecraftClient mc, TextRenderer tr);
    public abstract int height(MinecraftClient mc, TextRenderer tr);
    public abstract void draw(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y);

    public int[] position(DawnConfig c, int sw, int sh, int w, int h) {
        int[] p = c.pos.get(id);
        int x, y;
        if (p != null && p.length >= 2) {
            x = p[0];
            y = p[1];
        } else {
            x = ax == 1 ? sw - w - ox : ox;
            y = ay == 1 ? sh - h - oy : (ay == 2 ? sh / 2 - h / 2 + oy : oy);
        }
        x = Math.max(0, Math.min(x, sw - w));
        y = Math.max(0, Math.min(y, sh - h));
        return new int[]{x, y};
    }
}
