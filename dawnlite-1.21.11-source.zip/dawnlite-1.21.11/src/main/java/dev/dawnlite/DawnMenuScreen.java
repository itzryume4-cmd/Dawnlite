package dev.dawnlite;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

public class DawnMenuScreen extends Screen {
    private static final int HEADER = 24;
    private static final String[] TABS = {"HUD", "Gameplay", "Optimizer", "Utility"};

    private final Screen parent;
    private int tab = 0;
    private double scroll = 0;
    private final long openNs = System.nanoTime();
    private long lastNs = openNs;
    private float fade = 0f;
    private float frameDt = 0f;
    private final List<Row> rows = new ArrayList<>();
    private int px, py, pw, ph, side, cx, cy, cw, ch;

    private Row pressRow;
    private double pressY;
    private boolean scrolling;
    private SliderRow dragSlider;

    public DawnMenuScreen(Screen parent) {
        super(Text.literal("DawnLite"));
        this.parent = parent;
    }

    // ================= rows =================
    private abstract class Row {
        int h = 24;
        int lx, ly, lw;

        abstract void draw(DrawContext ctx, int x, int y, int w, boolean hover);

        void click(double mx, double my) {}
    }

    private class HeaderRow extends Row {
        final String text;

        HeaderRow(String text) { this.text = text; this.h = 18; }

        void draw(DrawContext ctx, int x, int y, int w, boolean hover) {
            lx = x; ly = y; lw = w;
            ctx.drawText(textRenderer, text, x + 4, y + 8, c(DawnConfig.accentColor()), false);
        }
    }

    private class ToggleRow extends Row {
        final String name, desc;
        final BooleanSupplier get;
        final Consumer<Boolean> set;
        float anim = -1f;

        ToggleRow(String name, String desc, BooleanSupplier get, Consumer<Boolean> set) {
            this.name = name; this.desc = desc; this.get = get; this.set = set;
            this.h = desc.isEmpty() ? 22 : 28;
        }

        void draw(DrawContext ctx, int x, int y, int w, boolean hover) {
            lx = x; ly = y; lw = w;
            boolean on = get.getAsBoolean();
            if (anim < 0) anim = on ? 1f : 0f;
            anim += ((on ? 1f : 0f) - anim) * Math.min(1f, frameDt * 14f);
            Gfx.round(ctx, x, y + 1, w, h - 2, 3, c(hover ? 0xFF262B40 : 0xFF1E2233));
            int maxW = w - 8 - 36;
            int ny = desc.isEmpty() ? y + (h - 8) / 2 : y + 5;
            ctx.drawText(textRenderer, textRenderer.trimToWidth(name, maxW), x + 8, ny, c(0xFFE8EAF2), false);
            if (!desc.isEmpty()) {
                ctx.drawText(textRenderer, textRenderer.trimToWidth(desc, maxW), x + 8, y + 16, c(0xFF8A90A8), false);
            }
            int sx = x + w - 32, sy = y + (h - 12) / 2;
            Gfx.round(ctx, sx, sy, 24, 12, 6, c(Gfx.lerp(0xFF3A4057, DawnConfig.accentColor(), anim)));
            Gfx.round(ctx, sx + 2 + (int) (12 * anim), sy + 2, 8, 8, 4, c(0xFFFFFFFF));
        }

        void click(double mx, double my) { set.accept(!get.getAsBoolean()); }
    }

    private class ButtonRow extends Row {
        final String name, desc;
        final Runnable action;

        ButtonRow(String name, String desc, Runnable action) {
            this.name = name; this.desc = desc; this.action = action;
            this.h = desc.isEmpty() ? 22 : 28;
        }

        void draw(DrawContext ctx, int x, int y, int w, boolean hover) {
            lx = x; ly = y; lw = w;
            int accent = DawnConfig.accentColor();
            Gfx.round(ctx, x, y + 1, w, h - 2, 3, c(hover ? Gfx.lerp(0xFF262B40, accent, 0.25f) : 0xFF1E2233));
            int maxW = w - 8 - 16;
            int ny = desc.isEmpty() ? y + (h - 8) / 2 : y + 5;
            ctx.drawText(textRenderer, textRenderer.trimToWidth(name, maxW), x + 8, ny, c(0xFFE8EAF2), false);
            if (!desc.isEmpty()) {
                ctx.drawText(textRenderer, textRenderer.trimToWidth(desc, maxW), x + 8, y + 16, c(0xFF8A90A8), false);
            }
            ctx.drawText(textRenderer, ">", x + w - 14, y + (h - 8) / 2, c(accent), false);
        }

        void click(double mx, double my) { action.run(); }
    }

    private class SliderRow extends Row {
        final String name, suffix;
        final IntSupplier get;
        final IntConsumer set;
        final int min, max;

        SliderRow(String name, String suffix, int min, int max, IntSupplier get, IntConsumer set) {
            this.name = name; this.suffix = suffix; this.min = min; this.max = max; this.get = get; this.set = set;
            this.h = 32;
        }

        void draw(DrawContext ctx, int x, int y, int w, boolean hover) {
            lx = x; ly = y; lw = w;
            int accent = DawnConfig.accentColor();
            int v = get.getAsInt();
            Gfx.round(ctx, x, y + 1, w, h - 2, 3, c(hover || dragSlider == this ? 0xFF262B40 : 0xFF1E2233));
            ctx.drawText(textRenderer, name, x + 8, y + 6, c(0xFFE8EAF2), false);
            String s = v + suffix;
            ctx.drawText(textRenderer, s, x + w - 8 - textRenderer.getWidth(s), y + 6, c(accent), false);
            int tx = x + 8, tw = w - 16, ty = y + 21;
            float frac = (v - min) / (float) (max - min);
            Gfx.round(ctx, tx, ty, tw, 4, 2, c(0xFF3A4057));
            Gfx.round(ctx, tx, ty, Math.max(2, (int) (tw * frac)), 4, 2, c(accent));
            Gfx.round(ctx, tx + (int) (tw * frac) - 4, ty - 2, 8, 8, 4, c(0xFFFFFFFF));
        }

        void drag(double mx) {
            double f = (mx - (lx + 8)) / (double) (lw - 16);
            f = Math.max(0, Math.min(1, f));
            set.accept((int) Math.round(min + f * (max - min)));
        }
    }

    private class AccentRow extends Row {
        AccentRow() { this.h = 34; }

        void draw(DrawContext ctx, int x, int y, int w, boolean hover) {
            lx = x; ly = y; lw = w;
            Gfx.round(ctx, x, y + 1, w, h - 2, 3, c(0xFF1E2233));
            ctx.drawText(textRenderer, "Warna aksen", x + 8, y + 6, c(0xFFE8EAF2), false);
            int sel = Math.floorMod(DawnConfig.get().accent, DawnConfig.ACCENTS.length);
            for (int i = 0; i < DawnConfig.ACCENTS.length; i++) {
                int sx = x + 8 + i * 18, sy = y + 17;
                if (i == sel) Gfx.round(ctx, sx - 2, sy - 2, 16, 16, 4, c(0xFFFFFFFF));
                Gfx.round(ctx, sx, sy, 12, 12, 3, c(0xFF000000 | DawnConfig.ACCENTS[i]));
            }
        }

        void click(double mx, double my) {
            int i = (int) Math.floor((mx - (lx + 8)) / 18.0);
            if (i >= 0 && i < DawnConfig.ACCENTS.length && my >= ly + 15 && my <= ly + 32) {
                DawnConfig.get().accent = i;
                DawnConfig.save();
            }
        }
    }

    // ================= build =================
    private int c(int argb) { return Gfx.withAlpha(argb, fade); }

    private void header(String t) { rows.add(new HeaderRow(t)); }

    private void tog(String n, String d, BooleanSupplier g, Consumer<Boolean> s) {
        rows.add(new ToggleRow(n, d, g, v -> { s.accept(v); DawnConfig.save(); }));
    }

    private void optTog(String n, String d, BooleanSupplier g, Consumer<Boolean> s) {
        rows.add(new ToggleRow(n, d, g, v -> {
            s.accept(v);
            DawnConfig.save();
            Optimizer.apply(MinecraftClient.getInstance());
        }));
    }

    private void build() {
        rows.clear();
        DawnConfig c = DawnConfig.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (tab == 0) {
            header("MODUL HUD");
            tog("FPS", "Frame per detik", () -> c.fps, v -> c.fps = v);
            tog("CPS", "Klik per detik (kiri | kanan)", () -> c.cps, v -> c.cps = v);
            tog("Ping", "Latensi ke server", () -> c.ping, v -> c.ping = v);
            tog("Koordinat", "Posisi XYZ", () -> c.coords, v -> c.coords = v);
            tog("Arah", "Arah hadap (N/S/E/W)", () -> c.direction, v -> c.direction = v);
            tog("Kecepatan", "Blok per detik", () -> c.speed, v -> c.speed = v);
            tog("RAM", "Pemakaian memori game", () -> c.memory, v -> c.memory = v);
            tog("Jam", "Waktu nyata", () -> c.clock, v -> c.clock = v);
            tog("Hari", "Hari di dunia Minecraft", () -> c.day, v -> c.day = v);
            tog("Server", "Alamat server", () -> c.server, v -> c.server = v);
            tog("Keystrokes", "WASD + klik", () -> c.keystrokes, v -> c.keystrokes = v);
            tog("Armor HUD", "Armor + durability", () -> c.armor, v -> c.armor = v);
            tog("Potion Effects", "Efek aktif + sisa waktu", () -> c.potions, v -> c.potions = v);
            header("TAMPILAN");
            rows.add(new ButtonRow("Atur posisi HUD",
                    mc.player != null ? "Geser modul sesukamu" : "Masuk dunia dulu",
                    () -> { if (mc.player != null) mc.setScreen(new DawnHudEditor(this)); }));
            tog("Background HUD", "Panel transparan di belakang modul", () -> c.hudBackground, v -> c.hudBackground = v);
            rows.add(new SliderRow("Opacity background", "%", 10, 90, () -> c.hudOpacity, v -> c.hudOpacity = v));
            rows.add(new AccentRow());
        } else if (tab == 1) {
            header("GAMEPLAY");
            tog("Fullbright", "Terang total di gua & malam", () -> c.fullbright, v -> c.fullbright = v);
            tog("Auto sprint", "Lari terus saat maju", () -> c.autoSprint, v -> c.autoSprint = v);
            rows.add(new ToggleRow("Toggle sprint", "Tekan sekali buat lari",
                    () -> mc.options.getSprintToggled().getValue(),
                    v -> { mc.options.getSprintToggled().setValue(v); mc.options.write(); }));
            rows.add(new ToggleRow("Toggle sneak", "Tekan sekali buat jongkok",
                    () -> mc.options.getSneakToggled().getValue(),
                    v -> { mc.options.getSneakToggled().setValue(v); mc.options.write(); }));
            header("ZOOM (tahan tombol C)");
            tog("Zoom", "Aktifkan fitur zoom", () -> c.zoom, v -> c.zoom = v);
            tog("Zoom halus", "Animasi masuk & keluar", () -> c.smoothZoom, v -> c.smoothZoom = v);
            rows.add(new SliderRow("Kuat zoom (FOV)", "%", 10, 60, () -> c.zoomPct, v -> c.zoomPct = v));
        } else if (tab == 2) {
            header("PRESET CEPAT");
            rows.add(new ButtonRow("Aktifkan semua", "Boost FPS maksimal", () -> {
                Optimizer.setAll(true);
                DawnConfig.save();
                Optimizer.apply(mc);
            }));
            rows.add(new ButtonRow("Matikan semua", "Kembalikan setelan asli", () -> {
                Optimizer.setAll(false);
                DawnConfig.save();
                Optimizer.apply(mc);
            }));
            header("OPTIMIZER");
            optTog("Graphics Fast", "Daun & efek lebih ringan", () -> c.optGraphics, v -> c.optGraphics = v);
            optTog("Partikel minimal", "Kurangi efek partikel", () -> c.optParticles, v -> c.optParticles = v);
            optTog("Matikan awan", "Hemat render langit", () -> c.optClouds, v -> c.optClouds = v);
            optTog("Entity distance 50%", "Entity jauh nggak dirender", () -> c.optEntityDist, v -> c.optEntityDist = v);
            optTog("Tanpa bayangan entity", "Hemat render", () -> c.optShadows, v -> c.optShadows = v);
            optTog("Biome blend 0", "Warna rumput/air lebih ringan", () -> c.optBiome, v -> c.optBiome = v);
            optTog("FPS tanpa batas", "Max FPS unlimited", () -> c.optFps, v -> c.optFps = v);
            optTog("Matikan VSync", "Kurangi input lag", () -> c.optVsync, v -> c.optVsync = v);
            optTog("Batas render distance 8", "Render & simulation maks 8", () -> c.optDistance, v -> c.optDistance = v);
        } else {
            header("PERINGATAN: bisa kena ban di server publik");
            tog("Fly", "Terbang bebas, langsung aktif", () -> c.fly, v -> c.fly = v);
            rows.add(new SliderRow("Kecepatan terbang", "x", 1, 10, () -> c.flySpeed, v -> c.flySpeed = v));
            tog("Speed", "Lari lebih cepat di tanah", () -> c.speedHack, v -> c.speedHack = v);
            rows.add(new SliderRow("Kecepatan lari", "%", 100, 300, () -> c.speedPct, v -> c.speedPct = v));
            tog("No Fall", "Nggak kena damage jatuh", () -> c.noFall, v -> c.noFall = v);
            tog("Anti AFK", "Loncat otomatis tiap 30 detik", () -> c.antiAfk, v -> c.antiAfk = v);
            tog("Shield Breaker", "Pindah ke kapak saat lawan block", () -> c.shieldBreaker, v -> c.shieldBreaker = v);
            header("LUNGE SWAP (butuh spear Lunge di hotbar)");
            tog("Lunge Swap", "Tahan tombol Lunge: ganti ke spear, jab, balik", () -> c.lungeSwap, v -> c.lungeSwap = v);
            rows.add(new SliderRow("Jeda lunge", " tick", 3, 20, () -> c.lungeInterval, v -> c.lungeInterval = v));
        }
        scroll = Math.min(scroll, maxScroll());
    }

    // ================= layout =================
    private void layout(int ofs) {
        pw = Math.min(width - 12, 400);
        ph = Math.min(height - 12, 240);
        px = (width - pw) / 2;
        py = (height - ph) / 2 + ofs;
        side = Math.min(86, pw / 4);
        cx = px + side + 4;
        cy = py + HEADER + 5;
        cw = pw - side - 10;
        ch = ph - HEADER - 9;
    }

    private int totalHeight() {
        int t = 0;
        for (Row r : rows) t += r.h;
        return t;
    }

    private double maxScroll() { return Math.max(0, totalHeight() - ch); }

    private void clampScroll() { scroll = Math.max(0, Math.min(scroll, maxScroll())); }

    @Override
    protected void init() {
        layout(0);
        build();
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ================= render =================
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime();
        frameDt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        float t = Math.min(1f, (now - openNs) / 240_000_000f);
        fade = 1f - (1f - t) * (1f - t);
        layout((int) ((1f - fade) * 14));
        clampScroll();
        int accent = DawnConfig.accentColor();

        ctx.fill(0, 0, width, height, Gfx.withAlpha(0xB0070810, fade));
        Gfx.round(ctx, px - 1, py - 1, pw + 2, ph + 2, 5, c((accent & 0xFFFFFF) | 0x66000000));
        Gfx.round(ctx, px, py, pw, ph, 4, c(0xFF141622));

        // header
        Gfx.round(ctx, px, py, pw, HEADER, 4, c(0xFF1B1E2E));
        ctx.fill(px, py + HEADER - 4, px + pw, py + HEADER, c(0xFF1B1E2E));
        ctx.fill(px, py + HEADER, px + pw, py + HEADER + 1, c((accent & 0xFFFFFF) | 0x80000000));
        ctx.drawText(textRenderer, "DawnLite", px + 10, py + 8, c(accent), true);
        ctx.drawText(textRenderer, "v1.3 - 1.21.11", px + 16 + textRenderer.getWidth("DawnLite"), py + 8, c(0xFF6B7189), false);
        boolean hClose = in(mx, my, px + pw - 22, py + 4, 16, 16);
        Gfx.round(ctx, px + pw - 22, py + 4, 16, 16, 4, c(hClose ? 0xFF3A2230 : 0xFF232739));
        ctx.drawText(textRenderer, "x", px + pw - 22 + (16 - textRenderer.getWidth("x")) / 2, py + 8,
                c(hClose ? 0xFFFF6B7A : 0xFFB8BED6), false);

        // sidebar
        ctx.fill(px, py + HEADER + 1, px + side, py + ph, c(0xFF171A28));
        for (int i = 0; i < TABS.length; i++) {
            int ty = py + HEADER + 7 + i * 26;
            boolean active = i == tab;
            boolean hov = in(mx, my, px + 4, ty, side - 8, 22);
            if (active || hov) Gfx.round(ctx, px + 4, ty, side - 8, 22, 4, c(active ? 0xFF22273A : 0xFF1D2133));
            if (active) Gfx.round(ctx, px + 4, ty + 4, 2, 14, 1, c(accent));
            ctx.drawText(textRenderer, TABS[i], px + 12, ty + 7, c(active ? 0xFFFFFFFF : 0xFF8A90A8), false);
        }

        // content
        ctx.enableScissor(cx, cy, cx + cw, cy + ch);
        int y = cy - (int) scroll;
        for (Row r : rows) {
            if (y + r.h > cy && y < cy + ch) {
                boolean hov = dragSlider == null && !scrolling
                        && mx >= cx && mx < cx + cw && my >= Math.max(y, cy) && my < Math.min(y + r.h, cy + ch);
                r.draw(ctx, cx, y, cw, hov);
            }
            y += r.h;
        }
        ctx.disableScissor();

        // scrollbar
        int total = totalHeight();
        if (total > ch) {
            int barH = Math.max(14, ch * ch / total);
            int barY = cy + (int) ((ch - barH) * (scroll / maxScroll()));
            Gfx.round(ctx, px + pw - 4, barY, 2, barH, 1, c((accent & 0xFFFFFF) | 0xAA000000));
        }
    }

    // ================= input =================
    private Row rowAt(double my) {
        int y = cy - (int) scroll;
        for (Row r : rows) {
            if (my >= y && my < y + r.h) return r;
            y += r.h;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        if (in(mx, my, px + pw - 22, py + 4, 16, 16)) {
            close();
            return true;
        }
        for (int i = 0; i < TABS.length; i++) {
            if (in(mx, my, px + 4, py + HEADER + 7 + i * 26, side - 8, 22)) {
                if (tab != i) {
                    tab = i;
                    scroll = 0;
                    build();
                }
                return true;
            }
        }
        if (in(mx, my, cx, cy, cw, ch)) {
            Row r = rowAt(my);
            scrolling = false;
            pressRow = null;
            if (r instanceof SliderRow s) {
                dragSlider = s;
                s.drag(mx);
            } else if (r != null) {
                pressRow = r;
                pressY = my;
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        double mx = click.x(), my = click.y();
        if (dragSlider != null) {
            dragSlider.drag(mx);
            return true;
        }
        if (pressRow != null) {
            if (!scrolling && Math.abs(my - pressY) > 4) scrolling = true;
            if (scrolling) {
                scroll -= dy;
                clampScroll();
            }
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        double mx = click.x(), my = click.y();
        if (dragSlider != null) {
            dragSlider = null;
            DawnConfig.save();
            return true;
        }
        if (pressRow != null) {
            if (!scrolling) pressRow.click(mx, my);
            pressRow = null;
            scrolling = false;
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll -= vAmount * 22;
        clampScroll();
        return true;
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
