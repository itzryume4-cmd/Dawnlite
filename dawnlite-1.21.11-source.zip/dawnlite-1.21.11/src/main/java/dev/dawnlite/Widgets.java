package dev.dawnlite;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Function;
import java.util.function.Predicate;

public final class Widgets {
    public static final List<HudWidget> ALL = new ArrayList<>();
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    public static final int FAKE_NV_TICKS = 1_000_000;

    private Widgets() {}

    static void panel(DrawContext ctx, DawnConfig c, int x, int y, int w, int h) {
        if (!c.hudBackground) return;
        int a = Math.max(0, Math.min(100, c.hudOpacity)) * 255 / 100;
        Gfx.round(ctx, x, y, w, h, 3, (a << 24) | 0x0E1018);
    }

    static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return (n >= 1 && n < r.length) ? r[n] : String.valueOf(n);
    }

    static {
        ALL.add(new Stat("fps", "FPS", 4, c -> c.fps,
                mc -> new String[]{"FPS", String.valueOf(mc.getCurrentFps())}));
        ALL.add(new Stat("cps", "CPS", 21, c -> c.cps,
                mc -> new String[]{"CPS", DawnHud.leftCps() + " | " + DawnHud.rightCps()}));
        ALL.add(new Stat("ping", "Ping", 38, c -> c.ping, mc -> {
            if (mc.player == null) return null;
            if (mc.isInSingleplayer() || mc.getNetworkHandler() == null) return new String[]{"Ping", "-"};
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            return new String[]{"Ping", e == null ? "-" : e.getLatency() + " ms"};
        }));
        ALL.add(new Stat("coords", "Koordinat", 55, c -> c.coords, mc -> {
            if (mc.player == null) return null;
            return new String[]{"XYZ", mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ()};
        }));
        ALL.add(new Stat("direction", "Arah", 72, c -> c.direction, mc -> {
            if (mc.player == null) return null;
            String n = mc.player.getHorizontalFacing().asString();
            return new String[]{"Arah", Character.toUpperCase(n.charAt(0)) + n.substring(1)};
        }));
        ALL.add(new Stat("speed", "Kecepatan", 89, c -> c.speed,
                mc -> new String[]{"Speed", String.format(Locale.US, "%.1f b/s", DawnHud.speed())}));
        ALL.add(new Stat("memory", "RAM", 106, c -> c.memory, mc -> {
            Runtime rt = Runtime.getRuntime();
            long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
            long max = rt.maxMemory() / 1048576L;
            return new String[]{"RAM", used + "/" + max + " MB"};
        }));
        ALL.add(new Stat("clock", "Jam", 123, c -> c.clock,
                mc -> new String[]{"Jam", LocalTime.now().format(CLOCK)}));
        ALL.add(new Stat("day", "Hari", 140, c -> c.day, mc -> {
            if (mc.world == null) return null;
            return new String[]{"Hari", String.valueOf(mc.world.getTime() / 24000L)};
        }));
        ALL.add(new Stat("server", "Server", 157, c -> c.server, mc -> {
            if (mc.getCurrentServerEntry() != null) return new String[]{"IP", mc.getCurrentServerEntry().address};
            return new String[]{"IP", "Singleplayer"};
        }));
        ALL.add(new Keystrokes());
        ALL.add(new Armor());
        ALL.add(new Potions());
    }

    // ---------------- stat pill ----------------
    static final class Stat extends HudWidget {
        private final Predicate<DawnConfig> en;
        private final Function<MinecraftClient, String[]> val;

        Stat(String id, String name, int oy, Predicate<DawnConfig> en, Function<MinecraftClient, String[]> val) {
            super(id, name, 0, 0, 4, oy);
            this.en = en;
            this.val = val;
        }

        public boolean enabled(DawnConfig c) { return en.test(c); }

        public int width(MinecraftClient mc, TextRenderer tr) {
            String[] v = val.apply(mc);
            if (v == null) return 0;
            return 6 + tr.getWidth(v[0]) + 4 + tr.getWidth(v[1]) + 6;
        }

        public int height(MinecraftClient mc, TextRenderer tr) { return 15; }

        public void draw(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y) {
            String[] v = val.apply(mc);
            if (v == null) return;
            DawnConfig c = DawnConfig.get();
            int w = 6 + tr.getWidth(v[0]) + 4 + tr.getWidth(v[1]) + 6;
            int a = DawnConfig.accentColor();
            panel(ctx, c, x, y, w, 15);
            ctx.fill(x, y + 3, x + 2, y + 12, a);
            ctx.drawTextWithShadow(tr, v[0], x + 6, y + 4, a);
            ctx.drawTextWithShadow(tr, v[1], x + 6 + tr.getWidth(v[0]) + 4, y + 4, 0xFFFFFFFF);
        }
    }

    // ---------------- keystrokes ----------------
    static final class Keystrokes extends HudWidget {
        Keystrokes() { super("keystrokes", "Keystrokes", 0, 1, 4, 4); }

        public boolean enabled(DawnConfig c) { return c.keystrokes; }
        public int width(MinecraftClient mc, TextRenderer tr) { return 62; }
        public int height(MinecraftClient mc, TextRenderer tr) { return 62; }

        private void key(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w, int h, boolean down) {
            int a = DawnConfig.accentColor();
            int bg = down ? ((a & 0xFFFFFF) | 0xDD000000) : 0x99101018;
            Gfx.round(ctx, x, y, w, h, 3, bg);
            int col = down ? 0xFF101018 : 0xFFFFFFFF;
            ctx.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2, col, false);
        }

        public void draw(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y) {
            var o = mc.options;
            key(ctx, tr, "W", x + 21, y, 20, 20, o.forwardKey.isPressed());
            key(ctx, tr, "A", x, y + 22, 20, 20, o.leftKey.isPressed());
            key(ctx, tr, "S", x + 21, y + 22, 20, 20, o.backKey.isPressed());
            key(ctx, tr, "D", x + 42, y + 22, 20, 20, o.rightKey.isPressed());
            key(ctx, tr, "L " + DawnHud.leftCps(), x, y + 44, 30, 18, o.attackKey.isPressed());
            key(ctx, tr, "R " + DawnHud.rightCps(), x + 32, y + 44, 30, 18, o.useKey.isPressed());
        }
    }

    // ---------------- armor ----------------
    static final class Armor extends HudWidget {
        private static final EquipmentSlot[] SLOTS = {
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
        };

        Armor() { super("armor", "Armor HUD", 1, 2, 4, 0); }

        public boolean enabled(DawnConfig c) { return c.armor; }

        public int width(MinecraftClient mc, TextRenderer tr) {
            if (mc.player == null) return 0;
            for (EquipmentSlot sl : SLOTS) if (!mc.player.getEquippedStack(sl).isEmpty()) return 56;
            return 0;
        }

        public int height(MinecraftClient mc, TextRenderer tr) { return 76; }

        public void draw(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y) {
            if (mc.player == null) return;
            DawnConfig c = DawnConfig.get();
            panel(ctx, c, x, y, 56, 76);
            for (int row = 0; row < 4; row++) {
                ItemStack st = mc.player.getEquippedStack(SLOTS[row]);
                if (st.isEmpty()) continue;
                int iy = y + 2 + row * 18;
                ctx.drawItem(st, x + 3, iy);
                if (st.isDamageable()) {
                    int max = st.getMaxDamage();
                    int pct = max <= 0 ? 100 : 100 - st.getDamage() * 100 / max;
                    int col = Gfx.lerp(0xFFFF5555, 0xFF55FF77, pct / 100f);
                    ctx.drawTextWithShadow(tr, pct + "%", x + 23, iy + 5, col);
                }
            }
        }
    }

    // ---------------- potion effects ----------------
    static final class Potions extends HudWidget {
        Potions() { super("potions", "Potion Effects", 1, 0, 4, 4); }

        public boolean enabled(DawnConfig c) { return c.potions; }

        private List<StatusEffectInstance> list(MinecraftClient mc) {
            List<StatusEffectInstance> out = new ArrayList<>();
            if (mc.player == null) return out;
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                if (e.getDuration() > 900000) continue; // night vision palsu dari Fullbright
                out.add(e);
            }
            return out;
        }

        private static String label(StatusEffectInstance e) {
            return e.getEffectType().value().getName().getString() + " " + roman(e.getAmplifier() + 1);
        }

        private static String time(StatusEffectInstance e) {
            if (e.isInfinite()) return "**:**";
            int sec = e.getDuration() / 20;
            return (sec / 60) + ":" + String.format(Locale.US, "%02d", sec % 60);
        }

        public int width(MinecraftClient mc, TextRenderer tr) {
            List<StatusEffectInstance> l = list(mc);
            if (l.isEmpty()) return 0;
            int w = 70;
            for (StatusEffectInstance e : l) w = Math.max(w, 14 + tr.getWidth(label(e)) + 10 + tr.getWidth(time(e)) + 6);
            return w;
        }

        public int height(MinecraftClient mc, TextRenderer tr) {
            return list(mc).size() * 12 + 4;
        }

        public void draw(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y) {
            List<StatusEffectInstance> l = list(mc);
            if (l.isEmpty()) return;
            DawnConfig c = DawnConfig.get();
            int w = width(mc, tr);
            panel(ctx, c, x, y, w, l.size() * 12 + 4);
            boolean flash = (System.currentTimeMillis() / 250) % 2 == 0;
            int i = 0;
            for (StatusEffectInstance e : l) {
                int ry = y + 2 + i * 12;
                ctx.fill(x + 5, ry + 3, x + 10, ry + 8, 0xFF000000 | e.getEffectType().value().getColor());
                boolean low = !e.isInfinite() && e.getDuration() < 200;
                int col = (low && flash) ? 0xFFFF5555 : 0xFFFFFFFF;
                ctx.drawTextWithShadow(tr, label(e), x + 14, ry + 2, col);
                String t = time(e);
                ctx.drawTextWithShadow(tr, t, x + w - 6 - tr.getWidth(t), ry + 2, low && flash ? 0xFFFF5555 : 0xFFB8BED6);
                i++;
            }
        }
    }
}
