package dev.dawnlite;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class DawnLiteClient implements ClientModInitializer {
    public static KeyBinding zoomKey;
    public static KeyBinding menuKey;
    public static KeyBinding lungeKey;

    private static double zoomCur = 1.0;
    private static long zoomNs = 0;

    private static boolean flyWasOn = false;
    private static int afkTicks = 0;
    private static int sbPrev = -1;
    private static int sbTimer = 0;
    private static int lungeState = 0;
    private static int lungePrev = -1;
    private static int lungeCooldown = 0;

    public static boolean isZooming() {
        return zoomKey != null && zoomKey.isPressed();
    }

    /** Pengali FOV (1.0 = normal). Dipanggil dari mixin GameRenderer. */
    public static double zoomMultiplier() {
        DawnConfig c = DawnConfig.get();
        long now = System.nanoTime();
        double dt = zoomNs == 0 ? 0 : (now - zoomNs) / 1e9;
        zoomNs = now;
        dt = Math.min(dt, 0.1);
        double target = (c.zoom && isZooming()) ? c.zoomPct / 100.0 : 1.0;
        if (c.smoothZoom) {
            zoomCur += (target - zoomCur) * Math.min(1.0, dt * 12.0);
            if (Math.abs(zoomCur - target) < 0.001) zoomCur = target;
        } else {
            zoomCur = target;
        }
        return zoomCur;
    }

    // ---------------- fullbright ----------------
    private static boolean fakeNightVision(ClientPlayerEntity p) {
        StatusEffectInstance e = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        return e != null && e.getDuration() > 900000;
    }

    private static void tickFullbright(ClientPlayerEntity p) {
        boolean has = fakeNightVision(p);
        if (DawnConfig.get().fullbright) {
            if (!has) {
                p.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION, Widgets.FAKE_NV_TICKS, 0, false, false, false));
            }
        } else if (has) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    // ---------------- fly / speed / nofall / antiafk ----------------
    private static void tickUtility(MinecraftClient client, ClientPlayerEntity p) {
        DawnConfig c = DawnConfig.get();
        var ab = p.getAbilities();

        if (c.fly) {
            if (!flyWasOn) {
                ab.allowFlying = true;
                ab.flying = true;
            }
            ab.allowFlying = true;
            ab.setFlySpeed(0.05f * c.flySpeed);
            flyWasOn = true;
        } else if (flyWasOn) {
            flyWasOn = false;
            ab.setFlySpeed(0.05f);
            if (!p.isCreative() && !p.isSpectator()) {
                ab.allowFlying = false;
                ab.flying = false;
            }
        }

        var o = client.options;
        boolean moving = o.forwardKey.isPressed() || o.backKey.isPressed()
                || o.leftKey.isPressed() || o.rightKey.isPressed();
        if (c.speedHack && moving && p.isOnGround() && client.currentScreen == null) {
            Vec3d v = p.getVelocity();
            double h = Math.hypot(v.x, v.z);
            if (h > 0.02) {
                double target = Math.min(0.28 * c.speedPct / 100.0, 1.0);
                p.setVelocity(v.x / h * target, v.y, v.z / h * target);
            }
        }

        if (c.noFall && p.fallDistance > 2.5 && !p.isOnGround() && !ab.flying) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
        }

        if (c.antiAfk) {
            if (++afkTicks >= 600) {
                afkTicks = 0;
                if (p.isOnGround()) {
                    Vec3d v = p.getVelocity();
                    p.setVelocity(v.x, 0.42, v.z);
                }
            }
        } else {
            afkTicks = 0;
        }
    }

    // ---------------- shield breaker ----------------
    private static void tickShieldBreaker(MinecraftClient client, ClientPlayerEntity p) {
        boolean want = false;
        if (DawnConfig.get().shieldBreaker && client.currentScreen == null
                && client.options.attackKey.isPressed()
                && client.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof PlayerEntity target
                && target != p && target.isBlocking()) {
            want = true;
        }
        PlayerInventory inv = p.getInventory();
        if (want) {
            if (!(inv.getStack(inv.getSelectedSlot()).getItem() instanceof AxeItem)) {
                for (int i = 0; i < 9; i++) {
                    if (inv.getStack(i).getItem() instanceof AxeItem) {
                        if (sbPrev < 0) sbPrev = inv.getSelectedSlot();
                        inv.setSelectedSlot(i);
                        break;
                    }
                }
            }
            sbTimer = 10;
        } else if (sbPrev >= 0) {
            if (--sbTimer <= 0) {
                inv.setSelectedSlot(sbPrev);
                sbPrev = -1;
            }
        }
    }

    // ---------------- lunge swap ----------------
    private static int lungeLevel(ItemStack st) {
        if (st.isEmpty()) return 0;
        ItemEnchantmentsComponent ench = st.getEnchantments();
        for (RegistryEntry<Enchantment> e : ench.getEnchantments()) {
            boolean isLunge = e.getKey().map(k -> "lunge".equals(k.getValue().getPath())).orElse(false);
            if (isLunge) return ench.getLevel(e);
        }
        return 0;
    }

    private static void tickLunge(MinecraftClient client, ClientPlayerEntity p) {
        DawnConfig c = DawnConfig.get();
        PlayerInventory inv = p.getInventory();
        if (lungeCooldown > 0) lungeCooldown--;

        // tick setelah jab diproses: kembalikan slot
        if (lungeState == 1) {
            if (lungePrev >= 0) inv.setSelectedSlot(lungePrev);
            lungeState = 0;
            lungePrev = -1;
            lungeCooldown = Math.max(1, c.lungeInterval - 1);
            return;
        }
        if (!c.lungeSwap || client.currentScreen != null || lungeKey == null
                || !lungeKey.isPressed() || lungeCooldown > 0) {
            return;
        }
        int best = -1, bestLvl = 0;
        for (int i = 0; i < 9; i++) {
            int lvl = lungeLevel(inv.getStack(i));
            if (lvl > bestLvl) {
                bestLvl = lvl;
                best = i;
            }
        }
        if (best < 0) return;
        lungePrev = inv.getSelectedSlot();
        inv.setSelectedSlot(best);
        KeyBinding.onKeyPressed(KeyBindingHelper.getBoundKeyOf(client.options.attackKey));
        lungeState = 1;
    }

    @Override
    public void onInitializeClient() {
        DawnConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("dawnlite", "main"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dawnlite.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, category));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dawnlite.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        lungeKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dawnlite.lunge", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, category));

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> Optimizer.apply(client));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new DawnMenuScreen(client.currentScreen));
            }
            ClientPlayerEntity p = client.player;
            if (p == null) {
                DawnHud.resetSpeed();
                return;
            }
            DawnHud.updateSpeed(p.getX(), p.getZ());
            tickFullbright(p);
            tickUtility(client, p);
            tickShieldBreaker(client, p);
            tickLunge(client, p);
            if (DawnConfig.get().autoSprint
                    && client.currentScreen == null
                    && client.options.forwardKey.isPressed()
                    && !p.isSneaking()
                    && !p.horizontalCollision
                    && p.getHungerManager().getFoodLevel() > 6) {
                p.setSprinting(true);
            }
        });

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of("dawnlite", "hud"), DawnHud::render);

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof GameMenuScreen || screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("DawnLite"),
                                        b -> MinecraftClient.getInstance().setScreen(new DawnMenuScreen(screen)))
                                .dimensions(4, 4, 70, 20).build());
            }
        });
    }
}
