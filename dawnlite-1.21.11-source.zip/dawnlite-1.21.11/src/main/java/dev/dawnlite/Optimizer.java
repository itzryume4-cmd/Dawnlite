package dev.dawnlite;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/**
 * Preset setting ringan. Nilai asli disimpan di config dan dipulihkan saat dimatikan.
 */
public final class Optimizer {
    private Optimizer() {}

    private static void remember(DawnConfig c, String k, String v) {
        c.origs.putIfAbsent(k, v);
    }

    public static void apply(MinecraftClient mc) {
        DawnConfig c = DawnConfig.get();
        GameOptions o = mc.options;
        if (o == null) return;
        try {
            // Graphics
            if (c.optGraphics) {
                remember(c, "graphics", o.getGraphicsMode().getValue().name());
                o.getGraphicsMode().setValue(GraphicsMode.FAST);
            } else {
                String v = c.origs.remove("graphics");
                if (v != null) o.getGraphicsMode().setValue(GraphicsMode.valueOf(v));
            }
            // Partikel
            if (c.optParticles) {
                remember(c, "particles", o.getParticles().getValue().name());
                o.getParticles().setValue(ParticlesMode.MINIMAL);
            } else {
                String v = c.origs.remove("particles");
                if (v != null) o.getParticles().setValue(ParticlesMode.valueOf(v));
            }
            // Awan
            if (c.optClouds) {
                remember(c, "clouds", o.getCloudRenderMode().getValue().name());
                o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            } else {
                String v = c.origs.remove("clouds");
                if (v != null) o.getCloudRenderMode().setValue(CloudRenderMode.valueOf(v));
            }
            // Jarak render entity
            if (c.optEntityDist) {
                remember(c, "entdist", String.valueOf(o.getEntityDistanceScaling().getValue()));
                o.getEntityDistanceScaling().setValue(0.5);
            } else {
                String v = c.origs.remove("entdist");
                if (v != null) o.getEntityDistanceScaling().setValue(Double.parseDouble(v));
            }
            // Bayangan entity
            if (c.optShadows) {
                remember(c, "shadows", String.valueOf(o.getEntityShadows().getValue()));
                o.getEntityShadows().setValue(false);
            } else {
                String v = c.origs.remove("shadows");
                if (v != null) o.getEntityShadows().setValue(Boolean.parseBoolean(v));
            }
            // Biome blend
            if (c.optBiome) {
                remember(c, "biome", String.valueOf(o.getBiomeBlendRadius().getValue()));
                o.getBiomeBlendRadius().setValue(0);
            } else {
                String v = c.origs.remove("biome");
                if (v != null) o.getBiomeBlendRadius().setValue(Integer.parseInt(v));
            }
            // FPS tanpa batas
            if (c.optFps) {
                remember(c, "maxfps", String.valueOf(o.getMaxFps().getValue()));
                o.getMaxFps().setValue(260);
            } else {
                String v = c.origs.remove("maxfps");
                if (v != null) o.getMaxFps().setValue(Integer.parseInt(v));
            }
            // VSync
            if (c.optVsync) {
                remember(c, "vsync", String.valueOf(o.getEnableVsync().getValue()));
                o.getEnableVsync().setValue(false);
            } else {
                String v = c.origs.remove("vsync");
                if (v != null) o.getEnableVsync().setValue(Boolean.parseBoolean(v));
            }
            // Batas render & simulation distance
            if (c.optDistance) {
                remember(c, "view", String.valueOf(o.getViewDistance().getValue()));
                remember(c, "sim", String.valueOf(o.getSimulationDistance().getValue()));
                if (o.getViewDistance().getValue() > 8) o.getViewDistance().setValue(8);
                if (o.getSimulationDistance().getValue() > 8) o.getSimulationDistance().setValue(8);
            } else {
                String v = c.origs.remove("view");
                if (v != null) o.getViewDistance().setValue(Integer.parseInt(v));
                String s = c.origs.remove("sim");
                if (s != null) o.getSimulationDistance().setValue(Integer.parseInt(s));
            }
            o.write();
        } catch (Exception ignored) {}
        DawnConfig.save();
    }

    public static void setAll(boolean v) {
        DawnConfig c = DawnConfig.get();
        c.optGraphics = v;
        c.optParticles = v;
        c.optClouds = v;
        c.optEntityDist = v;
        c.optShadows = v;
        c.optBiome = v;
        c.optFps = v;
        c.optVsync = v;
        c.optDistance = v;
    }
}
